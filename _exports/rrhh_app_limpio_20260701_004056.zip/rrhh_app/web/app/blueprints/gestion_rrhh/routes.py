# web/app/blueprints/gestion_rrhh/routes.py
from __future__ import annotations

import csv
import io

from flask import Response, render_template, request, url_for
from flask_login import current_user, login_required
from werkzeug.routing import BuildError

from ...auth.decorators import role_required
from ...services.gestion_rrhh import construir_bandeja_gestion_rrhh, filtrar_tareas
from . import bp


ROLES_GESTION_RRHH_VER = (
    "ADMIN",
    "ADMINISTRATIVO",
    "JEFATURA",
    "PREVENCION",
    "FINANZAS",
    "SOLO_LECTURA",
    "OPERADOR",
    "REVISOR",
)


def _resolver_url(endpoint: str | None, params: dict | None) -> str | None:
    if not endpoint:
        return None
    try:
        return url_for(endpoint, **(params or {}))
    except (BuildError, TypeError, ValueError):
        return None


def _hidratar_urls(tareas: list[dict]) -> list[dict]:
    for tarea in tareas:
        tarea["url"] = _resolver_url(tarea.get("endpoint"), tarea.get("params"))
        tarea["secondary_url"] = _resolver_url(tarea.get("secondary_endpoint"), tarea.get("secondary_params"))
    return tareas


@bp.get("/")
@login_required
@role_required(*ROLES_GESTION_RRHH_VER)
def index():
    bandeja = construir_bandeja_gestion_rrhh(current_user)

    filtros = {
        "prioridad": request.args.get("prioridad", "todas"),
        "categoria": request.args.get("categoria", "todas"),
        "q": request.args.get("q", ""),
    }
    tareas_filtradas = filtrar_tareas(bandeja["tareas"], **filtros)
    _hidratar_urls(tareas_filtradas)

    return render_template(
        "gestion_rrhh/index.html",
        bandeja=bandeja,
        tareas=tareas_filtradas,
        filtros=filtros,
    )


@bp.get("/exportar.csv")
@login_required
@role_required(*ROLES_GESTION_RRHH_VER)
def exportar_csv():
    bandeja = construir_bandeja_gestion_rrhh(current_user)
    filtros = {
        "prioridad": request.args.get("prioridad", "todas"),
        "categoria": request.args.get("categoria", "todas"),
        "q": request.args.get("q", ""),
    }
    tareas = filtrar_tareas(bandeja["tareas"], **filtros)

    output = io.StringIO()
    writer = csv.writer(output, delimiter=";")
    writer.writerow(["Prioridad", "Categoria", "Estado", "Titulo", "Detalle", "Contexto", "Plazo"])
    for t in tareas:
        writer.writerow([
            t.get("prioridad_label", ""),
            t.get("categoria_label", ""),
            t.get("estado", ""),
            t.get("titulo", ""),
            t.get("detalle", ""),
            t.get("contexto", ""),
            t.get("dias_texto", ""),
        ])

    return Response(
        output.getvalue(),
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": "attachment; filename=bandeja_gestion_rrhh.csv"},
    )
