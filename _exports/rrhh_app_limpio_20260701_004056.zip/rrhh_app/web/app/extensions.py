# web/app/extensions.py

from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_migrate import Migrate

login_manager = LoginManager()
login_manager.login_view = "auth.login"

db = SQLAlchemy()
migrate = Migrate()
