# web/app/services/gestion_rrhh.py
from __future__ import annotations

from collections import Counter
from datetime import date
from typing import Any

from .cumplimiento_laboral import construir_panel_cumplimiento


PRIORIDAD_RANK = {"alta": 1, "media": 2, "baja": 3}
PRIORIDAD_LABEL = {"alta": "Alta", "media": "Media", "baja": "Baja"}
PRIORIDAD_CLASS = {"alta": "danger", "media": "warning", "baja": "info"}

CATEGORIA_LABEL = {
    "contratos": "Contratos",
    "jornada": "Jornada",
    "remuneraciones": "Remuneraciones",
    "prevencion": "Prevención",
    "parametros": "Parámetros",
    "datos": "Datos maestros",
}


def _int_or_zero(value: Any) -> int:
    try:
        if value is None:
            return 0
        return int(value)
    except Exception:
        return 0


def _dias_texto(dias: int | None) -> str:
    if dias is None:
        return "Sin fecha límite"
    if dias < 0:
        return f"Vencido hace {abs(dias)} día(s)"
    if dias == 0:
        return "Vence hoy"
    return f"Vence en {dias} día(s)"


def _task(
    *,
    task_id: str,
    categoria: str,
    prioridad: str,
    icono: str,
    titulo: str,
    detalle: str,
    contexto: str = "",
    estado: str = "Pendiente",
    dias: int | None = None,
    endpoint: str | None = None,
    params: dict[str, Any] | None = None,
    action_label: str = "Gestionar",
    secondary_endpoint: str | None = "cumplimiento_laboral.index",
    secondary_params: dict[str, Any] | None = None,
    secondary_label: str = "Ver cumplimiento",
) -> dict[str, Any]:
    prioridad = prioridad if prioridad in PRIORIDAD_RANK else "media"
    categoria = categoria if categoria in CATEGORIA_LABEL else "datos"
    return {
        "id": task_id,
        "categoria": categoria,
        "categoria_label": CATEGORIA_LABEL[categoria],
        "prioridad": prioridad,
        "prioridad_label": PRIORIDAD_LABEL[prioridad],
        "prioridad_class": PRIORIDAD_CLASS[prioridad],
        "prioridad_rank": PRIORIDAD_RANK[prioridad],
        "icono": icono,
        "titulo": titulo,
        "detalle": detalle,
        "contexto": contexto,
        "estado": estado,
        "dias": dias,
        "dias_texto": _dias_texto(dias),
        "endpoint": endpoint,
        "params": params or {},
        "action_label": action_label,
        "secondary_endpoint": secondary_endpoint,
        "secondary_params": secondary_params or {},
        "secondary_label": secondary_label,
    }


def _contexto_contrato(row: dict[str, Any]) -> str:
    partes = [
        row.get("trabajador"),
        row.get("rut"),
        row.get("obra"),
        row.get("cargo"),
    ]
    return " · ".join(str(p).strip() for p in partes if p and str(p).strip() and str(p).strip() != "-")


def construir_bandeja_gestion_rrhh(user, *, max_por_bloque: int = 12) -> dict[str, Any]:
    """Construye una bandeja operativa a partir de señales ya disponibles.

    La Fase 5 no crea tablas nuevas: transforma alertas de cumplimiento en una
    lista de gestión priorizada, enlazando al módulo donde corresponde resolver
    cada caso.
    """
    panel = construir_panel_cumplimiento(user)
    listas = panel.get("listas", {}) or {}
    metricas = panel.get("metricas", {}) or {}
    tareas: list[dict[str, Any]] = []

    if not panel.get("parametro_actual"):
        tareas.append(_task(
            task_id="parametros-laborales-mes",
            categoria="parametros",
            prioridad="alta",
            icono="📐",
            titulo="Cargar parámetros laborales del mes",
            detalle=f"No hay parámetro laboral cargado para el período {panel.get('periodo_actual')}. Esto afecta controles de sueldo mínimo y cálculos dependientes.",
            contexto="Indicadores Previred / sueldo mínimo / topes previsionales",
            estado="Requiere carga",
            dias=0,
            endpoint="parametros_laborales.listado",
            action_label="Revisar parámetros",
        ))

    for row in (listas.get("contratos_vencidos") or [])[:max_por_bloque]:
        dias = row.get("dias_restantes")
        tareas.append(_task(
            task_id=f"contrato-vigente-vencido-{row.get('id')}",
            categoria="contratos",
            prioridad="alta",
            icono="🚨",
            titulo="Contrato vigente con fecha vencida",
            detalle=f"El contrato #{row.get('id')} figura vigente, pero su fecha de término es {row.get('fecha_termino')}.",
            contexto=_contexto_contrato(row),
            estado="Regularizar",
            dias=dias,
            endpoint="contratos.contrato_detalle",
            params={"contrato_id": row.get("id")},
            action_label="Abrir contrato",
        ))

    for row in (listas.get("contratos_por_vencer") or [])[:max_por_bloque]:
        dias = row.get("dias_restantes")
        prioridad = "alta" if dias is not None and dias <= 7 else "media"
        tareas.append(_task(
            task_id=f"contrato-por-vencer-{row.get('id')}",
            categoria="contratos",
            prioridad=prioridad,
            icono="⏳",
            titulo="Definir continuidad de contrato",
            detalle=f"Contrato #{row.get('id')} vence el {row.get('fecha_termino')}. Conviene definir extensión, término o paso a indefinido.",
            contexto=_contexto_contrato(row),
            estado="Por definir",
            dias=dias,
            endpoint="contratos.contrato_detalle",
            params={"contrato_id": row.get("id")},
            action_label="Ver contrato",
            secondary_endpoint="contratos_vencimientos.listado",
            secondary_label="Ver tablero",
        ))

    for row in (listas.get("contratos_42") or [])[:max_por_bloque]:
        tareas.append(_task(
            task_id=f"jornada-sobre-42-{row.get('id')}",
            categoria="jornada",
            prioridad="media",
            icono="🕒",
            titulo="Revisar jornada superior a 42 horas",
            detalle=f"Contrato #{row.get('id')} registra {row.get('horas_semanales')} horas semanales. Revisar si corresponde anexo de ajuste de jornada.",
            contexto=_contexto_contrato(row),
            estado="Revisar jornada",
            endpoint="contratos.contrato_detalle",
            params={"contrato_id": row.get("id")},
            action_label="Ver contrato",
            secondary_endpoint="anexos_masivos.nuevo_ley_40_horas",
            secondary_label="Crear anexo masivo",
        ))

    for row in (listas.get("contratos_bajo_minimo") or [])[:max_por_bloque]:
        tareas.append(_task(
            task_id=f"sueldo-bajo-minimo-{row.get('id')}",
            categoria="remuneraciones",
            prioridad="alta",
            icono="💰",
            titulo="Revisar sueldo base bajo mínimo",
            detalle=f"Contrato #{row.get('id')} tiene sueldo base {row.get('sueldo_base')} y brecha estimada {row.get('brecha_sueldo')} respecto del mínimo parametrizado.",
            contexto=_contexto_contrato(row),
            estado="Reajustar / validar",
            endpoint="contratos.contrato_detalle",
            params={"contrato_id": row.get("id")},
            action_label="Ver contrato",
            secondary_endpoint="anexos_masivos.nuevo_sueldo_minimo",
            secondary_params={"proceso": "2026-06-22"},
            secondary_label="Crear anexo masivo",
        ))

    for row in (listas.get("docs_vencidos") or [])[:max_por_bloque]:
        tareas.append(_task(
            task_id=f"doc-prev-vencido-{row.get('id')}",
            categoria="prevencion",
            prioridad="alta",
            icono="🦺",
            titulo="Documento preventivo vencido",
            detalle=f"{row.get('tipo')} figura vencido o requiere renovación. Fecha vencimiento: {row.get('fecha_vencimiento')}.",
            contexto=" · ".join(str(p) for p in [row.get("trabajador"), row.get("obra"), row.get("estado")] if p and p != "-"),
            estado="Renovar",
            endpoint="prevencion_riesgos.documento_detalle",
            params={"documento_id": row.get("id")},
            action_label="Ver documento",
            secondary_endpoint="prevencion_riesgos.documentos_listado",
            secondary_label="Ver prevención",
        ))

    for row in (listas.get("docs_por_vencer") or [])[:max_por_bloque]:
        tareas.append(_task(
            task_id=f"doc-prev-por-vencer-{row.get('id')}",
            categoria="prevencion",
            prioridad="media",
            icono="📁",
            titulo="Documento preventivo por vencer",
            detalle=f"{row.get('tipo')} vence el {row.get('fecha_vencimiento')}. Conviene coordinar renovación antes del vencimiento.",
            contexto=" · ".join(str(p) for p in [row.get("trabajador"), row.get("obra"), row.get("estado")] if p and p != "-"),
            estado="Programar renovación",
            endpoint="prevencion_riesgos.documento_detalle",
            params={"documento_id": row.get("id")},
            action_label="Ver documento",
            secondary_endpoint="prevencion_riesgos.documentos_listado",
            secondary_label="Ver prevención",
        ))

    for row in (listas.get("epp_vencidos") or [])[:max_por_bloque]:
        tareas.append(_task(
            task_id=f"epp-vencido-{row.get('entrega_id')}-{row.get('tipo')}",
            categoria="prevencion",
            prioridad="media",
            icono="🥾",
            titulo="Reposición de EPP vencida",
            detalle=f"{row.get('tipo')} tiene reposición sugerida para {row.get('fecha_reposicion')}.",
            contexto=" · ".join(str(p) for p in [row.get("trabajador"), row.get("obra")] if p and p != "-"),
            estado="Reponer / actualizar",
            endpoint="prevencion_riesgos.epp_detalle" if row.get("entrega_id") else "prevencion_riesgos.epp_listado",
            params={"entrega_id": row.get("entrega_id")} if row.get("entrega_id") else {},
            action_label="Ver entrega",
            secondary_endpoint="prevencion_riesgos.epp_listado",
            secondary_label="Ver EPP",
        ))

    datos_agregados = [
        ("contratos-sin-sueldo", "Contratos sin sueldo base", _int_or_zero(metricas.get("contratos_sin_sueldo")), "remuneraciones", "media", "💸", "Completar remuneración base."),
        ("contratos-sin-horas", "Contratos sin horas semanales", _int_or_zero(metricas.get("contratos_sin_horas")), "jornada", "media", "⏱️", "Completar horas semanales para auditoría de jornada."),
        ("contratos-sin-datos", "Contratos con datos maestros incompletos", _int_or_zero(metricas.get("contratos_sin_datos")), "datos", "media", "🧩", "Completar empleador, obra, cargo o fecha de inicio."),
    ]
    for key, titulo, count, categoria, prioridad, icono, detalle in datos_agregados:
        if count <= 0:
            continue
        tareas.append(_task(
            task_id=key,
            categoria=categoria,
            prioridad=prioridad,
            icono=icono,
            titulo=titulo,
            detalle=f"Hay {count} registro(s) que requieren depuración administrativa. {detalle}",
            contexto="Calidad de datos contractual",
            estado="Depurar",
            endpoint="cumplimiento_laboral.index",
            action_label="Ver cumplimiento",
        ))

    tareas.sort(key=lambda t: (t["prioridad_rank"], 9999 if t.get("dias") is None else t.get("dias"), t["categoria_label"], t["titulo"]))

    prioridad_counter = Counter(t["prioridad"] for t in tareas)
    categoria_counter = Counter(t["categoria"] for t in tareas)
    tareas_7 = sum(1 for t in tareas if t.get("dias") is not None and t["dias"] <= 7)

    return {
        "panel": panel,
        "fecha": date.today(),
        "tareas": tareas,
        "resumen": {
            "total": len(tareas),
            "alta": prioridad_counter.get("alta", 0),
            "media": prioridad_counter.get("media", 0),
            "baja": prioridad_counter.get("baja", 0),
            "proximos_7": tareas_7,
            "categorias": dict(categoria_counter),
        },
        "categorias": CATEGORIA_LABEL,
        "prioridades": PRIORIDAD_LABEL,
    }


def filtrar_tareas(
    tareas: list[dict[str, Any]],
    *,
    prioridad: str | None = None,
    categoria: str | None = None,
    q: str | None = None,
) -> list[dict[str, Any]]:
    prioridad = (prioridad or "todas").strip().lower()
    categoria = (categoria or "todas").strip().lower()
    needle = (q or "").strip().lower()

    filtradas = []
    for tarea in tareas:
        if prioridad != "todas" and tarea.get("prioridad") != prioridad:
            continue
        if categoria != "todas" and tarea.get("categoria") != categoria:
            continue
        if needle:
            haystack = " ".join(str(tarea.get(k, "")) for k in ("titulo", "detalle", "contexto", "estado")).lower()
            if needle not in haystack:
                continue
        filtradas.append(tarea)
    return filtradas
