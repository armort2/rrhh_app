-- 20260519_anticipos_contrato_id.sql
-- Objetivo: convertir anticipos_detalles a trazabilidad por contrato.
-- Seguro para ejecutar varias veces.

ALTER TABLE anticipos_detalles
  ADD COLUMN IF NOT EXISTS contrato_id integer;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'fk_anticipos_detalles_contrato_id'
      AND conrelid = 'anticipos_detalles'::regclass
  ) THEN
    ALTER TABLE anticipos_detalles
      ADD CONSTRAINT fk_anticipos_detalles_contrato_id
      FOREIGN KEY (contrato_id)
      REFERENCES contratos(id)
      ON DELETE SET NULL;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS ix_anticipos_detalles_contrato_id
  ON anticipos_detalles (contrato_id);

CREATE INDEX IF NOT EXISTS ix_anticipos_detalles_nomina_contrato
  ON anticipos_detalles (nomina_id, contrato_id);
