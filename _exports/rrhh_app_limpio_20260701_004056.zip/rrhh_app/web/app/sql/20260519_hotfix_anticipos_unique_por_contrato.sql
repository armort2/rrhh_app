-- 20260519_hotfix_anticipos_unique_por_contrato.sql
-- Objetivo: retirar la restriccion antigua por trabajador y permitir multiples contratos
-- por trabajador dentro de una misma nomina de anticipos.
-- Seguro para ejecutar varias veces.

BEGIN;

-- 1) La restriccion antigua impide que una nomina tenga dos lineas del mismo trabajador,
-- aunque correspondan a contratos distintos.
ALTER TABLE anticipos_detalles
  DROP CONSTRAINT IF EXISTS ux_anticipos_detalles_nomina_trabajador;

-- Por si fue creada como indice unico directo en alguna version anterior.
DROP INDEX IF EXISTS ux_anticipos_detalles_nomina_trabajador;

-- 2) Aseguramos que exista contrato_id y sus indices base.
ALTER TABLE anticipos_detalles
  ADD COLUMN IF NOT EXISTS contrato_id integer;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'fk_anticipos_detalles_contrato_id'
      AND conrelid = 'anticipos_detalles'::regclass
  ) THEN
    ALTER TABLE anticipos_detalles
      ADD CONSTRAINT fk_anticipos_detalles_contrato_id
      FOREIGN KEY (contrato_id)
      REFERENCES contratos(id)
      ON DELETE SET NULL;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS ix_anticipos_detalles_contrato_id
  ON anticipos_detalles (contrato_id);

CREATE INDEX IF NOT EXISTS ix_anticipos_detalles_nomina_contrato
  ON anticipos_detalles (nomina_id, contrato_id);

-- 3) Nueva regla de negocio: no duplicar el mismo contrato dentro de la misma nomina.
-- Permite que el mismo trabajador aparezca mas de una vez si tiene contratos distintos.
CREATE UNIQUE INDEX IF NOT EXISTS ux_anticipos_detalles_nomina_contrato
  ON anticipos_detalles (nomina_id, contrato_id)
  WHERE contrato_id IS NOT NULL;

COMMIT;
