-- 20260609_update_horario_normal_42_horas.sql
-- Objetivo: actualizar el catálogo "Horario Normal" a jornada semanal de 42 horas.
-- Seguro para ejecutar varias veces: reemplaza los tramos del horario normal por la nueva distribución.

BEGIN;

WITH target AS (
    SELECT id
    FROM horarios
    WHERE nombre ILIKE '%Horario Normal%'
       OR descripcion ILIKE '%Lunes a jueves, de 08:00 hrs. a 13:00 hrs.%Viernes%14:00 hrs. a 17:00 hrs.%'
), deleted AS (
    DELETE FROM horario_tramos
    WHERE horario_id IN (SELECT id FROM target)
    RETURNING horario_id
), updated AS (
    UPDATE horarios
    SET descripcion = 'Lunes y Martes, de 08:00 hrs. a 13:00 hrs., y de 14:00 hrs. a 18:00 hrs. Miércoles a Viernes, de 08:00 hrs. a 13:00 hrs., y de 14:00 hrs. a 17:00 hrs.',
        actualizado_en = NOW()
    WHERE id IN (SELECT id FROM target)
    RETURNING id
)
INSERT INTO horario_tramos (horario_id, dia_semana, hora_inicio, hora_termino, orden)
SELECT id, dia_semana, hora_inicio::time, hora_termino::time, orden
FROM updated
CROSS JOIN (VALUES
    (0, '08:00', '13:00', 1),
    (0, '14:00', '18:00', 2),
    (1, '08:00', '13:00', 1),
    (1, '14:00', '18:00', 2),
    (2, '08:00', '13:00', 1),
    (2, '14:00', '17:00', 2),
    (3, '08:00', '13:00', 1),
    (3, '14:00', '17:00', 2),
    (4, '08:00', '13:00', 1),
    (4, '14:00', '17:00', 2)
) AS v(dia_semana, hora_inicio, hora_termino, orden);

COMMIT;
